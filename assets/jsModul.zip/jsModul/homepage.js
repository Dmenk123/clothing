let baseUrl = "";
$(document).ready(function() {
	//set active class to navbar
	var uriValue = "home";
	$('#li_nav_produk').removeClass('active');
	$('#li_nav_kontak').removeClass('active');
	$('#li_nav_faq').removeClass('active');
	$('#li_nav_login').removeClass('active');
	$('#li_nav_home').addClass('active');
});