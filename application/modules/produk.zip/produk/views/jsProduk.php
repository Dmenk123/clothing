<script src="<?php echo site_url('assets'); ?>/jsModul/produk.js"></script>
