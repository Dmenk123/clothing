<span class="hidden" id="base_url"><?php echo base_url();?></span>
	<script src="<?php echo site_url('assets'); ?>/jsModul/modal.js"></script>