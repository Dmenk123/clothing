<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Dmenk Clothing E-shop | Powered by : adminLTE</b>
    </div>
    <strong>Copyright &copy; 2020-<?php echo date('Y'); ?> admincoba@gmail.com </strong> All rights
    reserved.
</footer>