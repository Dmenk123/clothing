<?php 
$img_laporan = '<img src="/xampp/htdocs/e-commerce/assets/img/loggo.png">';
?>