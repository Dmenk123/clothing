<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
	<div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">© 2020 - <?php echo date('Y'); ?> Crazy Property Tycoon | admincoba@gmail.com.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="https://bootstrapious.com/e-commerce-templates">Bootstrapious</a> & <a href="https://fity.cz">Fity</a>
                    </p>
                </div>
            </div>
        </div>