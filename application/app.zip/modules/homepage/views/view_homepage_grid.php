<div class="container2" style="width:100%!important;">
               <!-- banner -->
             <!-- Images sourced from Wikimedia Commons http://commons.wikimedia.org/wiki/Main_page -->

        <div class="imageGrid">
        <div class="tile" style="background-image: url(<?php echo config_item('assets'); ?>img/main-slider6.jpg);">
            <div class="textWrapper"><h2>Pont de Bir-Hakeim, Paris</h2>
            <div class="content">The western part of the Pont de Bir-Hakeim seen at night. Buildings of the 16th arrondissement of Paris are visible in the background.</div>
            </div>
        </div><!--
        --><div class="tile" style="background-image: url(<?php echo config_item('assets'); ?>img/main-slider5.jpg);">
        <div class="textWrapper"><h2>Wiesen Viaduct, Switzerland</h2>
            <div class="content">A RhB Ge 4/4 II with a push–pull train crosses the Wiesen Viaduct between Wiesen and Filisur, Switzerland.</div>
        </div>
        </div><!--
        --><div class="tile" style="background-image: url(<?php echo config_item('assets'); ?>img/main-slider8.jpg);">
        <div class="textWrapper"><h2>Office building, Germany</h2>
            <div class="content">Office building of the LVM Insurance in Munster (Westphalia), Germany.</div>
        </div>
      
        
        
        
        </div>
                        <!-- banner -->
</div>