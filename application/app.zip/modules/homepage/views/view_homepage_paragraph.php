<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
			<div id="hot">

                <div class="box">
                    <div class="container">
                        
                        <div class="" style="margin-bottom:60px;">
                            <div class="feature-row__item">
                            
                                
                                
                        <style>#FeatureRowImage-feature-row {
                            max-width: 817.5px;
                            max-height: 545px;
                        }

                        #FeatureRowImageWrapper-feature-row {
                            max-width: 817.5px;
                        }
                        </style>

                              
                        
                            

                            <div class="feature-row__item feature-row__text feature-row__text--left">
                            
                                <!--<h2 class="h3">Raih Kesuksesan Anda</h2>-->
                            
                            <div class="rte rte-setting featured-row__subtext"><p style="font-size:24px; font-family: arial; color:black;"><strong>Koleksi ini nilainya kedepannya naik, Menguntungkan.</strong></p></div>
                            
                                <div class="rte rte-setting featured-row__subtext"><p>Kemarin saja dalam 2 bulan sudah naik 25%, Melaju Bagus. Saat Maret '21 harganya masih Rp. 1.200.000, di bulan Mei '21 sudah naik lagi menjadi Rp. 1.500.000.</p><p>Saran kami, anda memiliki 3 buah Jaket Hoodie dengan nomor serial masing-masing, karena 1 untuk dimiliki selamanya agar anda terus diakui dalam komunitas. 1 buah untuk dijual lagi, karena nilaianya akan terus naik. 1 lagi untuk dijual kembali di jangka waktu lebih panjang, karena nilainya akan lebih mahal.</p></div>
                            
                            
                            </div>

                            
                        </div>
                    </div>

                   
                     
                    <!-- </div> -->
                </div>

             
                <!-- /.container -->

            </div>
