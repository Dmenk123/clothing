<script src="<?php echo site_url('assets'); ?>/jsModul/homepage.js"></script>
