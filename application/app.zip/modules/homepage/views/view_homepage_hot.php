<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
			<div id="hot">

                <div class="box">
                    <div class="container">
                        
                        <div class="feature-row" style="margin-bottom:60px;">
                            <div class="feature-row__item">
                            
                                
                                
                        <style>#FeatureRowImage-feature-row {
                            max-width: 817.5px;
                            max-height: 545px;
                        }

                        #FeatureRowImageWrapper-feature-row {
                            max-width: 817.5px;
                        }
                        </style>

                                <div id="FeatureRowImageWrapper-feature-row" class="feature-row__image-wrapper js">
                                <div style="padding-top:66.66666666666666%;">
                                    <img id="FeatureRowImage-feature-row" class="feature-row__image lazyautosizes lazyloaded" data-widths="[180, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]" data-aspectratio="1.5" data-sizes="auto" alt="" data-srcset="//cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_180x.jpg?v=1612791388 180w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_360x.jpg?v=1612791388 360w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_540x.jpg?v=1612791388 540w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_720x.jpg?v=1612791388 720w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_900x.jpg?v=1612791388 900w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1080x.jpg?v=1612791388 1080w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1296x.jpg?v=1612791388 1296w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1512x.jpg?v=1612791388 1512w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1728x.jpg?v=1612791388 1728w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_2048x.jpg?v=1612791388 2048w" sizes="545px" srcset="//cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_180x.jpg?v=1612791388 180w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_360x.jpg?v=1612791388 360w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_540x.jpg?v=1612791388 540w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_720x.jpg?v=1612791388 720w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_900x.jpg?v=1612791388 900w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1080x.jpg?v=1612791388 1080w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1296x.jpg?v=1612791388 1296w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1512x.jpg?v=1612791388 1512w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_1728x.jpg?v=1612791388 1728w, //cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_2048x.jpg?v=1612791388 2048w">
                                </div>
                                </div>

                                <noscript>
                                <img src="//cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_600x600@2x.jpg?v=1612791388" alt="" class="feature-row__image" />
                                </noscript>
                            
                            </div>
                        
                            

                            <div class="feature-row__item feature-row__text feature-row__text--left">
                            
                                <h2 class="h3">Maintain your sweetness</h2>
                            
                            
                                <div class="rte rte-setting featured-row__subtext"><p>Life's goal is a flower of which sweetness is Honey.</p><p>Welcome to our store, Honey and Bath, your solution for beauty and wellness products.</p></div>
                            
                            
                            </div>

                            
                        </div>
                    </div>

                   
                     
                    <!-- </div> -->
                </div>

             
                <!-- /.container -->

            </div>
