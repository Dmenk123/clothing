<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
			<div id="hot">

                <div class="box">
                    <div class="container">
                        
                        <div class="feature-row" style="margin-bottom:60px;">
                            <div class="feature-row__item">
                            
                                
                                
                        <style>#FeatureRowImage-feature-row {
                            max-width: 817.5px;
                            max-height: 545px;
                        }

                        #FeatureRowImageWrapper-feature-row {
                            max-width: 817.5px;
                        }
                        </style>

                                <div id="FeatureRowImageWrapper-feature-row" class="feature-row__image-wrapper js">
                                <div style="padding-top:66.66666666666666%;">
                                   <img id="FeatureRowImage-feature-row" class="feature-row__image lazyautosizes lazyloaded" data-widths="[180, 360, 540, 720, 900, 1080, 1296, 1512, 1728, 2048]" data-aspectratio="1.5" data-sizes="auto" alt="" srcset="<?php echo base_url();?>/assets/img/Hot.jpg">
                                </div>
                                </div>

                                <noscript>
                                <img src="//cdn.shopify.com/s/files/1/0528/1975/5157/files/beautiful-girl-face-perfect-skine_600x600@2x.jpg?v=1612791388" alt="" class="feature-row__image" />
                                </noscript>
                            
                            </div>
                        
                            

                            <div class="feature-row__item feature-row__text feature-row__text--left">
                            
                                <!--<h2 class="h3">Raih Kesuksesan Anda</h2>-->
                            <div class="rte rte-setting featured-row__subtext"><p style="font-size:24px; font-family: arial; color:black;"><strong>Seperti koleksi Jam Tangan Mewah, setiap piecenya ada nomor serial.</strong></p></div>
                            
                                <div class="rte rte-setting featured-row__subtext"><p>Begitu pula Jaket Hoodie ini. Masing-masing piece diberi sertifikat sendiri &amp; nomor seri, bahkan di setiap sertifikat diberi quote yang berbeda-beda.</p><p>Dengan memiliki Jaket Hoodie ini, maka anda bisa masuk komunitas elite: Crazy Property Tycoon, bisa bertmu banyak networking kelas wahid; bagus untuk bisnis anda, maupun untuk keakraban.</p></div>
                            
                            
                            </div>

                            
                        </div>
                    </div>

                   
                     
                    <!-- </div> -->
                </div>

             
                <!-- /.container -->

            </div>
