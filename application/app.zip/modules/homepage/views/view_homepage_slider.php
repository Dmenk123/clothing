<div class="container2" style="width:100%!important;margin-top:-20px;">
                <!-- <div class="col-md-12"> -->
                    <div id="main-slider">
                        <!--<div class="item" >
                            <img src="<?php echo config_item('assets'); ?>img/main-slider5.jpg" alt="" class="hero hero--large hero-hero-1" >
                        </div>-->
                        <!--<div class="item">
                            <img class="hero hero--large hero-hero-1" src="<?php echo config_item('assets'); ?>img/main-slider6.jpg" alt="" >
                        </div>-->
                        <!--<div class="item">
                            <img class="img-responsive" src="<?php echo config_item('assets'); ?>img/main-slider7.jpg" alt="" style="width:1600px!important;">
                        </div>-->
                        <div class="item">
                            <img class="hero hero--large hero-hero-1" src="<?php echo config_item('assets'); ?>img/main-slider8.jpg" alt="">
                        </div>
                    </div>
                <!-- </div> -->
</div>
