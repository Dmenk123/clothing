<div class="container2" style="width:100%!important;">
               <!-- banner -->
              <div class="hero hero--medium hero-hero-2 hero__overlay box ratio-container js lazyloaded" id="Hero-hero-2" data-layout="full_width" data-parent-fit="cover" style="background-position: center center; background-image: url(https://crazypropertytycoon.com/assets/img/Bawah.jpg);">
                        <div class="hero__inner">
                            <!--<div class="page-width text-center"><h2 class="h1 mega-title"><p style="color:white;">Kesuksesanmu tergantung pada kelompok atau lingkaran yang kamu pilih hari ini.</p></h2><div class="rte-setting mega-subtitle"><p style="color:white;">Miliki Jaket Hoodienya. Sangat Langka, tiap kota hanya ada 70 pcs saja. </p></div></div>-->
                        </div>
                        </div>
                        </noscript></div>
                        <!-- banner -->
</div>