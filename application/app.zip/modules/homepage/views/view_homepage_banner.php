<div class="container2" style="width:100%!important;">
               <!-- banner -->
               <div class="hero hero--medium hero-hero-2 hero__overlay box ratio-container js lazyloaded" id="Hero-hero-2" data-layout="full_width" data-bg="//cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_300x300.jpg?v=1612790798" data-bgset="//cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_180x.jpg?v=1612790798 180w 120h,
                        //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_360x.jpg?v=1612790798 360w 240h,
                        //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_540x.jpg?v=1612790798 540w 360h,
                        
                        
            
                        //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona.jpg?v=1612790798 600w 400h" data-parent-fit="cover" style="background-position: center center; background-image: url(&quot;https://cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona.jpg?v=1612790798&quot;);">
                        <div class="hero__inner">
                            <div class="page-width text-center"><h2 class="h1 mega-title">The Future depends on what you do Today. Do Honey &amp; Bath.</h2><div class="rte-setting mega-subtitle"><p>The Beauty of your dreams would be achieved through the Beauty of you</p></div></div>
                        </div>
                        <source data-srcset="//cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_180x.jpg?v=1612790798 180w 120h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_360x.jpg?v=1612790798 360w 240h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_540x.jpg?v=1612790798 540w 360h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona.jpg?v=1612790798 600w 400h" sizes="1749px" srcset="//cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_180x.jpg?v=1612790798 180w 120h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_360x.jpg?v=1612790798 360w 240h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_540x.jpg?v=1612790798 540w 360h, //cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona.jpg?v=1612790798 600w 400h"><img alt="" class="lazyautosizes lazyloaded" data-sizes="auto" data-parent-fit="cover" sizes="1349px"></div>
                        <noscript>
                        <div class="hero hero--medium hero__overlay" style="background-image: url('//cdn.shopify.com/s/files/1/0528/1975/5157/files/woman-spa-salona_2048x.jpg?v=1612790798'); background-position: center center;">
                    </div>
                        </noscript></div>
                        <!-- banner -->
</div>