<div class="container2" style="width:100%!important;">
               <!-- banner -->
              <div class="hero hero--medium hero-hero-2 hero__overlay box ratio-container js lazyloaded" id="Hero-hero-2" data-layout="full_width" data-parent-fit="cover" style="background-position: center center; background-image: url(https://crazypropertytycoon.com/assets/img/tengah.jpg);">
                        <div class="hero__inner">
                            <div class="page-width text-center"><h2 class="h1 mega-title"><p style="color:white;">Koleksi ini sangat langka, karena di setiap kota dibatasi hanya boleh dimiliki oleh 70 orang terpilih saja. </p></h2><div class="rte-setting mega-subtitle"><p style="color:white;">Sehingga mereka bisa masuk dalam komunitas elite: Crazy Property Tycoon. </p></div></div>
                        </div>
                        </div>
                        </noscript></div>
                        <!-- banner -->
</div>