<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
			<div id="hot">

                <div class="box">
                    <div class="container">
                        
                        <div class="" style="margin-bottom:60px;">
                            <div class="feature-row__item">
                            
                                
                                
                        <style>#FeatureRowImage-feature-row {
                            max-width: 817.5px;
                            max-height: 545px;
                        }

                        #FeatureRowImageWrapper-feature-row {
                            max-width: 817.5px;
                        }
                        </style>

                              
                        
                            

                            <div class="feature-row__item feature-row__text feature-row__text--left">
                                <div style="text-align:center;">
                                     <a href="<?php echo  base_url();?>produk/katalog" class="btn btn-primary">Miliki Sekarang</a>
                                </div>
                               
                            
                            
                            </div>

                            
                        </div>
                    </div>

                   
                     
                    <!-- </div> -->
                </div>

             
                <!-- /.container -->

            </div>
