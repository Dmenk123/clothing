<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
			<div id="advantages">

                <div class="container">
                    <div class="same-height-row">
                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-heart"></i>
                                </div>

                                <h3><a href="#">Peduli kepada para pelanggan kami</a></h3>
                                <p>Kami akan berusaha agar dapat membuat para pelanggan kami merasa puas.</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-tags"></i>
                                </div>

                                <h3><a href="#">Harga Termurah</a></h3>
                                <p>Anda dapat memastikan bahwa produk kami paling murah diantara toko online yang serupa.</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-thumbs-up"></i>
                                </div>

                                <h3><a href="#">Jaminan 100% uang kembali</a></h3>
                                <p>Gratis 100% uang kembali apabila barang yang anda terima dapat terdapat kerusakan.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->

                </div>
                <!-- /.container -->

            </div>			