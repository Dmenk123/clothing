<!-- load gmaps api -->
<?php echo $map['js'];?>
<script src="<?php echo site_url('assets'); ?>/jsModul/kontak.js"></script>
